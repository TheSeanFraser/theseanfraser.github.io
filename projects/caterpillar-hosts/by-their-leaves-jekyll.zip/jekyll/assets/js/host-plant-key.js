(function(){

  // Data file location. Override before this script loads with:
  //   <script>window.HOST_PLANT_DATA_URL = "{{ '/assets/data/host-plant-key-data.json' | relative_url }}";</script>
  var DATA_URL = window.HOST_PLANT_DATA_URL || 'assets/data/host-plant-key-data.json';

  var bootResults = document.getElementById('results');
  var bootMeta = document.getElementById('meta');
  if (bootResults) {
    bootResults.innerHTML = '<div class="intro-empty"><h3>Loading the specimen records\u2026</h3>' +
      '<p>Fetching host-plant data for 7,500+ species. This happens once per visit \u2014 your browser caches it after that.</p></div>';
  }

  fetch(DATA_URL)
    .then(function(res){
      if (!res.ok) { throw new Error('HTTP ' + res.status); }
      return res.json();
    })
    .then(function(BUNDLE){ initApp(BUNDLE); })
    .catch(function(err){
      if (bootResults) {
        bootResults.innerHTML = '<div class="empty"><h3>Could not load the data file.</h3>' +
          '<p>Expected it at <code>' + DATA_URL + '</code>. Check that <code>host-plant-key-data.json</code> was copied into ' +
          '<code>assets/data/</code>, and that this path matches your site\'s baseurl.</p>' +
          '<p style="font-family:\'IBM Plex Mono\',monospace;font-size:12px;">' + err.message + '</p></div>';
      }
    });

  function initApp(BUNDLE) {
  const P = BUNDLE.payload;
  const COMMON_MAP = BUNDLE.commonMap;
  const COMMON_FAMILY_MAP = BUNDLE.commonFamilyMap;
  const STATES = BUNDLE.states;

  const R = P.records; // array of arrays
  // record: [id, common, familyIdx, subfamilyIdx, binomial, size, states, hostFamIdx[], hostGenIdx[], hostCatIdx, hostNotes, higherIdx, famCommonIdx, exoticIdx]
  const IDX = {id:0,common:1,family:2,subfamily:3,binomial:4,size:5,states:6,hostFam:7,hostGen:8,hostCat:9,hostNotes:10,higher:11,famCommon:12,exotic:13};

  // ---- build inverted indices ----
  const genusToRecords = new Map(); // genusIdx -> [recIdx]
  const famToRecords = new Map();
  R.forEach((rec, i) => {
    rec[IDX.hostGen].forEach(gi => {
      if(!genusToRecords.has(gi)) genusToRecords.set(gi, []);
      genusToRecords.get(gi).push(i);
    });
    rec[IDX.hostFam].forEach(fi => {
      if(!famToRecords.has(fi)) famToRecords.set(fi, []);
      famToRecords.get(fi).push(i);
    });
  });

  function isUncertain(rec){
    const h = (P.hiVals[rec[IDX.higher]]||'').toLowerCase();
    const ex = (P.exVals[rec[IDX.exotic]]||'').toLowerCase();
    return h.includes('stray') || h.includes('fugitive') || h.includes('unresolved') ||
           h.includes('undescribed') || h.includes('does not meet') || ex.includes('exotic');
  }
  function baseGroup(rec){
    const h = (P.hiVals[rec[IDX.higher]]||'');
    if(h.startsWith('Macromoth')) return 'Macromoth';
    if(h.startsWith('Micromoth')) return 'Micromoth';
    if(h.startsWith('Butterfly')) return 'Butterfly';
    if(h.startsWith('Skipper')) return 'Skipper';
    const hl = h.toLowerCase();
    if(hl.includes('macromoth')) return 'Macromoth';
    if(hl.includes('micromoth')) return 'Micromoth';
    if(hl.includes('butterfly')) return 'Butterfly';
    if(hl.includes('skipper')) return 'Skipper';
    return null;
  }

  // ---- search vocabulary for autocomplete ----
  const suggestions = [];
  Object.keys(COMMON_MAP).forEach(k => suggestions.push({label:k, kind:'plant', genus:COMMON_MAP[k]}));
  Object.keys(COMMON_FAMILY_MAP).forEach(k => suggestions.push({label:k, kind:'plant family', fam:COMMON_FAMILY_MAP[k]}));
  P.genusVocab.forEach(g => suggestions.push({label:g, kind:'genus', genus:g, sci:true}));
  P.famHostVocab.forEach(f => { if(f && f!=='Detritophagous') suggestions.push({label:f, kind:'family', fam:f, sci:true}); });

  function titleCase(s){ return s.replace(/\w\S*/g, t => t[0].toUpperCase()+t.slice(1)); }

  // ---- populate state select ----
  const stateSel = document.getElementById('stateSel');
  STATES.forEach(([code,name]) => {
    const o = document.createElement('option');
    o.value = code; o.textContent = name + ' (' + code + ')';
    stateSel.appendChild(o);
  });

  // ---- stats ----
  document.getElementById('statsBox').innerHTML =
    '<div><b>'+R.length.toLocaleString()+'</b>species on file</div>'+
    '<div><b>'+P.genusVocab.length.toLocaleString()+'</b>host genera</div>'+
    '<div><b>'+P.famHostVocab.length.toLocaleString()+'</b>plant families</div>';

  // ---- state ----
  let activeGroups = new Set(['Macromoth','Micromoth','Butterfly','Skipper']);
  let showUncertain = false;
  let stateFilter = '';
  let currentQuery = '';

  const qInput = document.getElementById('q');
  const suggestBox = document.getElementById('suggest');
  const metaBox = document.getElementById('meta');
  const caveatBox = document.getElementById('caveat');
  const resultsBox = document.getElementById('results');

  document.querySelectorAll('.toggle[data-group]').forEach(btn => {
    btn.addEventListener('click', () => {
      const g = btn.dataset.group;
      if(activeGroups.has(g)){ activeGroups.delete(g); btn.classList.remove('on'); }
      else { activeGroups.add(g); btn.classList.add('on'); }
      runSearch();
    });
  });
  document.getElementById('uncertainChk').addEventListener('change', e => {
    showUncertain = e.target.checked;
    runSearch();
  });
  stateSel.addEventListener('change', e => {
    stateFilter = e.target.value;
    runSearch();
  });
  document.querySelectorAll('.chip[data-ex]').forEach(c => {
    c.addEventListener('click', () => { qInput.value = c.dataset.ex; currentQuery = c.dataset.ex; hideSuggest(); runSearch(); });
  });
  document.getElementById('clearBtn').addEventListener('click', () => {
    qInput.value=''; currentQuery=''; hideSuggest(); runSearch(); qInput.focus();
  });

  function levenshtein(a,b){
    a=a.toLowerCase(); b=b.toLowerCase();
    const m=a.length,n=b.length;
    if(Math.abs(m-n) > 4) return 99; // quick reject
    const dp = Array.from({length:m+1}, (_,i)=>[i].concat(Array(n).fill(0)));
    for(let j=0;j<=n;j++) dp[0][j]=j;
    for(let i=1;i<=m;i++){
      for(let j=1;j<=n;j++){
        dp[i][j] = a[i-1]===b[j-1] ? dp[i-1][j-1] : 1+Math.min(dp[i-1][j-1],dp[i-1][j],dp[i][j-1]);
      }
    }
    return dp[m][n];
  }

  let suggestActive = -1;
  let suggestItems = [];

  function renderSuggest(query){
    const ql = query.trim().toLowerCase();
    if(ql.length < 2){ hideSuggest(); return; }
    let matches = suggestions.filter(s => s.label.toLowerCase().startsWith(ql));
    if(matches.length < 8){
      const contains = suggestions.filter(s => !s.label.toLowerCase().startsWith(ql) && s.label.toLowerCase().includes(ql));
      matches = matches.concat(contains);
    }
    // prioritize plant common names, then genus, then family
    const order = {plant:0,'plant family':1,genus:2,family:3};
    matches.sort((a,b)=> (order[a.kind]-order[b.kind]) || (a.label.length-b.label.length));
    matches = matches.slice(0,10);
    suggestItems = matches;
    suggestActive = -1;
    if(matches.length===0){ hideSuggest(); return; }
    suggestBox.innerHTML = matches.map((m,i)=>{
      const nm = m.sci ? '<i>'+m.label+'</i>' : titleCase(m.label);
      return '<div class="opt" data-i="'+i+'"><span class="nm">'+nm+'</span><span class="kind">'+m.kind+'</span></div>';
    }).join('');
    suggestBox.classList.add('show');
    suggestBox.querySelectorAll('.opt').forEach(el => {
      el.addEventListener('mousedown', (e) => {
        e.preventDefault();
        const m = suggestItems[+el.dataset.i];
        qInput.value = titleCase(m.label);
        currentQuery = m.label;
        hideSuggest();
        runSearch();
      });
    });
  }
  function hideSuggest(){ suggestBox.classList.remove('show'); suggestBox.innerHTML=''; }

  qInput.addEventListener('input', (e) => {
    currentQuery = e.target.value;
    renderSuggest(currentQuery);
    runSearch();
  });
  qInput.addEventListener('keydown', (e) => {
    const opts = suggestBox.querySelectorAll('.opt');
    if(e.key === 'ArrowDown'){ e.preventDefault(); suggestActive = Math.min(suggestActive+1, opts.length-1); updateActive(opts); }
    else if(e.key === 'ArrowUp'){ e.preventDefault(); suggestActive = Math.max(suggestActive-1,0); updateActive(opts); }
    else if(e.key === 'Enter'){
      if(suggestActive>=0 && suggestItems[suggestActive]){
        const m = suggestItems[suggestActive];
        qInput.value = titleCase(m.label);
        currentQuery = m.label;
      }
      hideSuggest(); runSearch();
    } else if(e.key === 'Escape'){ hideSuggest(); }
  });
  function updateActive(opts){
    opts.forEach(o=>o.classList.remove('active'));
    if(opts[suggestActive]){ opts[suggestActive].classList.add('active'); opts[suggestActive].scrollIntoView({block:'nearest'}); }
  }
  document.addEventListener('click', (e) => {
    if(!e.target.closest('.search-box')) hideSuggest();
  });

  function resolveQuery(q){
    const ql = q.trim().toLowerCase();
    if(!ql) return {genus:null, fam:null};
    if(COMMON_MAP[ql]) return {genus:COMMON_MAP[ql], fam:null, matchedLabel:ql};
    if(COMMON_FAMILY_MAP[ql]) return {genus:null, fam:COMMON_FAMILY_MAP[ql], matchedLabel:ql};
    // exact genus (case-insensitive)
    const gi = P.genusVocab.findIndex(g => g.toLowerCase() === ql);
    if(gi>=0) return {genus:P.genusVocab[gi], fam:null};
    const fi = P.famHostVocab.findIndex(f => f.toLowerCase() === ql);
    if(fi>=0) return {genus:null, fam:P.famHostVocab[fi]};
    return {genus:null, fam:null, notFound:true};
  }

  function stateMatches(rec, code){
    if(!code) return true;
    const s = rec[IDX.states];
    if(!s) return false;
    if(code === 'NL') return /\bNF(\[NL\])?\b/.test(s) || /\bNL\b/.test(s);
    if(code === 'NB') return new RegExp('\\bNB\\b').test(s);
    const re = new RegExp('\\b'+code+'(\\[[A-Za-z]+\\])?\\b');
    return re.test(s);
  }

  function buildCard(recIdx, matchType, matchedGenusName, matchedFamName){
    const rec = R[recIdx];
    const common = rec[IDX.common];
    const binom = rec[IDX.binomial];
    const fam = P.famVals[rec[IDX.family]];
    const sub = P.subVals[rec[IDX.subfamily]];
    const size = rec[IDX.size];
    const famCommon = P.fcVals[rec[IDX.famCommon]];
    const higher = P.hiVals[rec[IDX.higher]];
    const exotic = P.exVals[rec[IDX.exotic]];
    const notes = rec[IDX.hostNotes];
    const uncertain = isUncertain(rec);

    const genusNames = rec[IDX.hostGen].map(gi => P.genusVocab[gi]);
    const famNames = rec[IDX.hostFam].map(fi => P.famHostVocab[fi]);

    let hostTagsHtml = '';
    if(genusNames.length){
      hostTagsHtml += genusNames.map(g => {
        const hit = matchedGenusName && g === matchedGenusName;
        return '<span class="htag'+(hit?' hit':'')+'">'+g+'</span>';
      }).join('');
    } else if(famNames.length){
      hostTagsHtml += famNames.map(f => {
        const hit = matchedFamName && f === matchedFamName;
        return '<span class="htag fam'+(hit?' hit':'')+'">'+f+'</span>';
      }).join('');
    }

    const nameHtml = common ? esc(common) : '<span class="noname">Unnamed species</span>';
    const searchName = encodeURIComponent(binom.split('(')[0].trim());

    let flagHtml = '';
    if(exotic && exotic.toLowerCase().includes('exotic')) flagHtml = '<div class="exotic-flag">exotic</div>';
    else if(uncertain) flagHtml = '<div class="exotic-flag" style="color:var(--ink-soft);border-color:var(--line)">'+esc(strayLabel(higher))+'</div>';

    return '<div class="card-wrap">'+
      '<div class="bitemark"></div>'+
      '<div class="card">'+
        flagHtml+
        (common ? '<h3>'+nameHtml+'</h3>' : '<h3 class="noname">'+nameHtml+'</h3>')+
        '<div class="binom">'+esc(binom)+'</div>'+
        '<div class="metarow">'+
          '<span><b>'+esc(fam||'—')+'</b></span>'+
          (sub?'<span>'+esc(sub)+'</span>':'')+
          '<span>'+esc(famCommon||'')+'</span>'+
          (size?'<span>'+esc(size)+'</span>':'')+
        '</div>'+
        '<div class="hostwrap"><span class="lbl">'+(genusNames.length?'Documented host genera':'Documented host family')+'</span><div class="hosttags">'+hostTagsHtml+'</div></div>'+
        (notes?'<p class="notes">'+esc(notes)+'</p>':'')+
        '<div class="cardfoot">'+
          '<a href="https://www.inaturalist.org/search?q='+searchName+'&search_on=names" target="_blank" rel="noopener">Photos on iNaturalist ↗</a>'+
          '<a href="https://bugguide.net/index.php?q=search&keys='+searchName+'&search=Search" target="_blank" rel="noopener">BugGuide ↗</a>'+
        '</div>'+
      '</div>'+
    '</div>';
  }

  function strayLabel(h){
    const hl=(h||'').toLowerCase();
    if(hl.includes('stray')) return 'stray record';
    if(hl.includes('fugitive')) return 'unconfirmed';
    if(hl.includes('unresolved')) return 'unresolved';
    if(hl.includes('undescribed')) return 'undescribed';
    return 'uncertain';
  }

  function esc(s){
    if(s===null||s===undefined) return '';
    return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }

  function filterRecIndices(indices){
    return indices.filter(i => {
      const rec = R[i];
      const g = baseGroup(rec);
      if(g && !activeGroups.has(g)) return false;
      if(!showUncertain && isUncertain(rec)) return false;
      if(!stateMatches(rec, stateFilter)) return false;
      return true;
    });
  }

  function runSearch(){
    const q = currentQuery.trim();
    if(!q){
      metaBox.textContent = '';
      caveatBox.classList.remove('show');
      resultsBox.innerHTML = introEmptyHtml();
      return;
    }
    const resolved = resolveQuery(q);
    let genusHits = [], famHits = [];
    if(resolved.genus){
      const gi = P.genusVocab.indexOf(resolved.genus);
      genusHits = filterRecIndices(genusToRecords.get(gi) || []);
    } else if(resolved.fam){
      const fi = P.famHostVocab.indexOf(resolved.fam);
      famHits = filterRecIndices(famToRecords.get(fi) || []);
    } else {
      // no exact match: try loose contains match across genus vocab & common names, union results
      const ql = q.toLowerCase();
      const genusCandidates = P.genusVocab.filter(g => g.toLowerCase().includes(ql));
      const famCandidates = P.famHostVocab.filter(f => f.toLowerCase().includes(ql));
      const commonCandidates = Object.keys(COMMON_MAP).filter(c => c.includes(ql));
      let gset = new Set();
      genusCandidates.forEach(g => { const gi=P.genusVocab.indexOf(g); (genusToRecords.get(gi)||[]).forEach(r=>gset.add(r)); });
      commonCandidates.forEach(c => { const g=COMMON_MAP[c]; const gi=P.genusVocab.indexOf(g); (genusToRecords.get(gi)||[]).forEach(r=>gset.add(r)); });
      genusHits = filterRecIndices(Array.from(gset));
      let fset = new Set();
      famCandidates.forEach(f => { const fi=P.famHostVocab.indexOf(f); (famToRecords.get(fi)||[]).forEach(r=>fset.add(r)); });
      famHits = filterRecIndices(Array.from(fset)).filter(i => !gset.has(i));

      if(genusHits.length===0 && famHits.length===0){
        renderNoMatch(q);
        return;
      }
    }

    caveatBox.classList.add('show');
    const total = genusHits.length + famHits.length;
    metaBox.innerHTML = '<b>'+total.toLocaleString()+'</b> species documented on <b>'+esc(titleCase(resolved.matchedLabel||q))+'</b>'+
      (resolved.genus ? ' <span style="color:var(--ink-soft)">(genus <i style="font-style:italic">'+resolved.genus+'</i>)</span>' : '');

    let html = '';
    if(genusHits.length){
      genusHits.sort((a,b) => (R[a][IDX.common]?0:1) - (R[b][IDX.common]?0:1));
      html += genusHits.map(i => buildCard(i, 'genus', resolved.genus, null)).join('');
    }
    if(famHits.length){
      html += '<div class="empty" style="padding:8px 0 4px;"><div class="sectiontitle" style="margin:0;">Family-level records only</div></div>';
      html += famHits.map(i => buildCard(i, 'family', null, resolved.fam)).join('');
    }
    if(!html){
      renderNoMatch(q);
      return;
    }
    resultsBox.innerHTML = html;
  }

  function renderNoMatch(q){
    metaBox.innerHTML = '';
    caveatBox.classList.remove('show');
    // fuzzy suggestions
    const ql = q.toLowerCase();
    const pool = suggestions;
    const scored = pool.map(s => ({s, d: levenshtein(ql, s.label.toLowerCase())}))
      .sort((a,b)=>a.d-b.d).slice(0,5).filter(x=>x.d<=3);
    let dymHtml = '';
    if(scored.length){
      dymHtml = '<div class="didyoumean">Did you mean: ' + scored.map(x =>
        '<button data-l="'+esc(x.s.label)+'">'+(x.s.sci?'<i>'+esc(x.s.label)+'</i>':esc(titleCase(x.s.label)))+'</button>'
      ).join('') + '</div>';
    }
    resultsBox.innerHTML = '<div class="empty"><h3>Nothing on file for "'+esc(q)+'."</h3>'+
      '<p>This dataset indexes host plants by genus and family, so try the plant\'s genus name, or a common name for a well-known tree, wildflower, or crop. Very obscure or highly regional plants may not be resolved to genus in the source literature.</p>'+
      dymHtml+
      '</div>';
    resultsBox.querySelectorAll('.didyoumean button').forEach(b=>{
      b.addEventListener('click', ()=>{ qInput.value=titleCase(b.dataset.l); currentQuery=b.dataset.l; hideSuggest(); runSearch(); });
    });
  }

  function introEmptyHtml(){
    return '<div class="intro-empty">'+
      '<h3>Start with the plant, not the caterpillar.</h3>'+
      '<p>If you\'ve found a caterpillar (or chewed leaves) and don\'t know the plant well enough to search by species, that\'s fine — most people don\'t. Here\'s how to get a useful shortlist:</p>'+
      '<ol>'+
      '<li>Identify the plant to at least genus if you can — a plant ID app or the shape/arrangement of the leaves usually gets you there.</li>'+
      '<li>Type the plant\'s common or scientific name above.</li>'+
      '<li>Narrow by which states/provinces you\'re in, and which insect group looks right (moth, butterfly, skipper).</li>'+
      '<li>Compare the shortlist against photos — host plant narrows candidates, but markings confirm the species.</li>'+
      '</ol>'+
      '</div>';
  }

  runSearch();

  }

})();
