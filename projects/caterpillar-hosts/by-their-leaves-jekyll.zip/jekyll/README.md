# By Their Leaves — Jekyll drop-in

A host-plant search tool for identifying caterpillars, built from the UDel
Lepidoptera dataset (Shropshire & Tallamy 2025, ZooKeys). Ready to drop into
an existing Jekyll site.

## Files & where they go

Copy these into your Jekyll site root, preserving the paths:

```
your-site/
├── host-plant-key.html              ← the page itself
└── assets/
    ├── css/host-plant-key.css
    ├── js/host-plant-key.js
    └── data/host-plant-key-data.json   (1.5 MB — the dataset)
```

If your site already has files at `assets/css`, `assets/js`, `assets/data`,
these just add to them — nothing here overwrites existing files unless you
already have something with these exact names.

## That's it — it should just work

Build or serve your site as usual (`bundle exec jekyll serve`). The page is
published at **`/host-plant-key/`** (set by the `permalink:` in its front
matter — change that line to publish it somewhere else).

The page fetches its data client-side from `assets/data/host-plant-key-data.json`,
using Jekyll's `relative_url` filter so it resolves correctly whether your
site is served from a domain root or from a GitHub Pages project subpath
(`username.github.io/reponame/`).

## Making it match your site's look

The page ships as a **fully standalone document** (`layout: null` in its
front matter) — its own `<html>`, `<head>`, and a self-contained
field-guide/specimen-card visual style, so your theme's CSS won't fight with
it. Nothing to configure. If you'd rather it inherit your site's normal
header/nav/footer:

1. Change `layout: null` to your layout's name (e.g. `layout: default`).
2. Delete the `<!DOCTYPE html>`, `<html>`, `<head>`, and `<body>` tags from
   `host-plant-key.html` — keep everything *between* `<body>` and `</body>`.
3. Move the two `<link>`/`<script>` tags near the bottom of that file into
   your layout's `<head>` (or a `head.html` include), so the CSS and JS still
   load on this page.

## Editing the content

- **Header text, example chips, filters, footer citation** — plain HTML,
  edit directly in `host-plant-key.html`.
- **Visual style** (colors, type, card layout) — `assets/css/host-plant-key.css`.
  Colors are CSS custom properties at the top of the file (`--paper`, `--leaf`,
  `--ochre`, etc.) if you want to retheme it to match your site's palette.
- **Search/filter behavior** — `assets/js/host-plant-key.js`. The common-name
  → genus lookup (e.g. "oak" → *Quercus*) is the `COMMON_MAP`/`COMMON_FAMILY_MAP`
  object inside `assets/data/host-plant-key-data.json` (keys `commonMap` /
  `commonFamilyMap`) if you want to add more plants people are likely to search for.
- **The dataset itself** — regenerating `host-plant-key-data.json` requires
  the original spreadsheet and build script; ask if you need that redone with
  updated source data.

## Notes

- The JSON data file has **no front matter**, so Jekyll copies it as a static
  asset without running Liquid on it — this keeps builds fast even though the
  file is large, and avoids any risk of stray `{{ }}` text in the data being
  misread as Liquid.
- Because the page fetches data over HTTP, it needs to be viewed through a
  server (`jekyll serve`, or the live site) — opening the built HTML file
  directly via `file://` won't load the data, due to normal browser
  restrictions on local file fetches. This is not a problem once deployed or
  run through `jekyll serve`.
- Data caveats and citation are in the page footer — please keep that
  attribution intact, per the source dataset's terms.
